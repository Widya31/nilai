<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Mapel;
use App\Models\Nilai;

class NilaiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function show($id)
    {
        $nilai = Nilai::where('id_siswa', $id)->get();
        return view('nilais.detail', compact('nilai'));
    }

    public function index()
    {
        // Mengambil data nilai dengan siswa yang telah dimuat
        $nilais = Nilai::with('siswa')->latest()->get();
        // dd($nilais);

        // Mengelompokkan nilai berdasarkan siswa
        $groupedNilais = $nilais->groupBy('id_siswa');

        // Mengirimkan data ke view
        return view('nilais.index', compact('groupedNilais'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $siswas = Siswa::all();
        $mapels = Mapel::all();

        return view('nilais.create', compact('siswas', 'mapels'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate form
        $this->validate($request, [
            'id_siswa'     => 'required',
            'id_mapel.*'   => 'required',
            'nilai.*'      => 'required|numeric',
        ], [
            'id_siswa.required' => 'Nama siswa harus dipilih.'
        ]);

        // Iterate through each mapel submitted in the request
        foreach ($request->id_mapel as $key => $mapelId) {
            // Check if a similar record already exists in the database
            $existingNilai = Nilai::where('id_siswa', $request->id_siswa)
                                   ->where('id_mapel', $mapelId)
                                   ->first();

            // If similar record exists, skip adding the nilai
            if ($existingNilai) {
                continue;
            }

            // If similar record doesn't exist, create a new record
            Nilai::create([
                'id_siswa' => $request->id_siswa,
                'id_mapel' => $mapelId,
                'nilai'    => $request->nilai[$key],
            ]);
        }

        // Redirect to index with success message
        return redirect()->route('nilais.index')->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $nilai = Nilai::findOrFail($id);
        $siswas = Siswa::all();
        $mapels = Mapel::all();

        return view('nilais.edit', compact('nilai', 'siswas', 'mapels'));
    }

    public function update(Request $request, $id)
    {
        $nilai = Nilai::findOrFail($id);

        $request->validate([
            'id_siswa' => 'required|exists:siswas,id',
            'id_mapel' => 'required|exists:mapels,id',
            'nilai' => 'required|numeric',
        ]);

        $nilai->update($request->all());

        return redirect()->route('nilais.index')->with('success', 'Data nilai berhasil diupdate');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(nilai $nilai)
    {
        //delete post
        $nilai->delete();

        //redirect to index
        return redirect()->route('nilais.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
